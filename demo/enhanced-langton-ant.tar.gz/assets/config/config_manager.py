import json
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional

# Use pydantic on desktop, pure dataclasses on WASM (pygbag).
if sys.platform == "emscripten":

    @dataclass
    class AntConfig:
        limit: int
        types: dict

    @dataclass
    class TileConfig:
        resolution: int

    @dataclass
    class WorldConfig:
        fps: int
        grid_size: tuple
        window_size: tuple
        background_color: str
        ant_config: AntConfig
        tile_config: TileConfig
        random_seed: Optional[int] = None

    def _serialize(wc: WorldConfig) -> dict:
        return asdict(wc)

    def _deserialize(data: dict) -> WorldConfig:
        data["ant_config"] = AntConfig(**data["ant_config"])
        data["tile_config"] = TileConfig(**data["tile_config"])
        data["grid_size"] = tuple(data["grid_size"])
        data["window_size"] = tuple(data["window_size"])
        return WorldConfig(**data)

else:
    from pydantic import BaseModel, PositiveInt

    class AntConfig(BaseModel):
        limit: int
        types: dict[str, int]

    class TileConfig(BaseModel):
        resolution: PositiveInt

    class WorldConfig(BaseModel):
        fps: PositiveInt
        grid_size: tuple[PositiveInt, PositiveInt]
        window_size: tuple[PositiveInt, PositiveInt]
        background_color: str
        ant_config: AntConfig
        tile_config: TileConfig
        random_seed: Optional[int] = None

    def _serialize(wc: WorldConfig) -> dict:
        return wc.model_dump()

    def _deserialize(data: dict) -> WorldConfig:
        return WorldConfig(**data)


def default(path: str | Path):
    ant_config = AntConfig(limit=-1, types={"NormalAnt": 5})
    tile_config = TileConfig(resolution=15)
    world_config = WorldConfig(
        fps=60,
        grid_size=(30, 30),
        window_size=(500, 500),
        background_color="#FFFFFF",
        ant_config=ant_config,
        tile_config=tile_config,
    )

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as file:
        json.dump(_serialize(world_config), file, indent=4)

    return world_config


def load_config(path: str | Path) -> WorldConfig:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Cannot find {path.absolute()}.")

    with open(path) as file:
        config = json.load(file)

    return _deserialize(config)


def get() -> WorldConfig:
    path = "./settings/dev-settings.json"
    try:
        config = load_config(path)
    except FileNotFoundError:
        config = default(path)

    return config
